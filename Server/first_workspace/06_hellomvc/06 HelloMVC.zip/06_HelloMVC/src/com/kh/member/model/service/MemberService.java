package com.kh.member.model.service;

import static common.template.JDBCTemplate.close;
import static common.template.JDBCTemplate.commit;
import static common.template.JDBCTemplate.getConnection;
import static common.template.JDBCTemplate.rollback;

import java.sql.Connection;
import java.util.List;

import com.kh.member.model.dao.MemberDao;
import com.kh.member.model.vo.Member;


public class MemberService {
	private MemberDao dao=new MemberDao();
	
	public Member selectId(String id, String pw) {
		Connection conn=getConnection();
		Member m=dao.selectId(conn,id,pw);
		close(conn);
		return m;
	}

	public int insertMember(Member m) {
		Connection conn=getConnection();
		int result=dao.insertMember(conn,m);
		//트랜젝션처리
		if(result>0) {
			commit(conn);
		}else {
			rollback(conn);
		}
		close(conn);
		return result;
	}
	
	//아이디중복조회
	public boolean selectCheckId(String userId) {
		Connection conn=getConnection();
		boolean result=dao.selectCheckId(conn,userId);
		close(conn);
		return result;		
	}
	
	public Member selectMember(String userId) {
		Connection conn=getConnection();
		Member m=dao.selectMember(conn,userId);
		close(conn);
		return m;		
	}
	
	public int updateMember(Member m) {
		Connection conn=getConnection();
		int result=dao.updateMember(conn,m);
		if(result>0) {commit(conn);}
		else {rollback(conn);}
		close(conn);
		return result;		
	}
	
	
	public int deleteMember(String id) {
		Connection conn=getConnection();
		int result=dao.deleteMember(conn,id);
		if(result>0) {commit(conn);}
		else {rollback(conn);}
		close(conn);
		return result;
		
	}
	
	
	public int updatePassword(String userId,String password, String passwordNew) {
		Connection conn=getConnection();
		//1.일단 현재비밀번호가 맞는지 확인
		Member m=dao.selectId(conn, userId, password);
		int result=0;
		if(m!=null) {
			//password수정
			result=dao.updatePassword(conn,userId,passwordNew);
		}else {
			//수정못함!
			result=-1;
			//현재패스워드가 틀려서 입력이 안됐다는 구분
			//구분자로 해서 msg를 분기함.
		}
		if(result>0) {commit(conn);}
		else {rollback(conn);}
		close(conn);
		return result;
	}
	
	//관리자 회원관리
	public List<Member> selectList(){
		Connection conn=getConnection();
		List<Member> list=dao.selectList(conn);
		close(conn);
		return list;
	}
	
	//페이징처리를 위한 데이터 전체갯수확인
	public int selectCountMember() {
		Connection conn=getConnection();
		int count=dao.selectCountMember(conn);
		close(conn);
		return count;
	}
	
	//페이지 데이터 가져오기
	public List<Member> selectListPage(int cPage,int numPerPage){
		Connection conn=getConnection();
		List<Member> list=dao.selectListPage(conn,cPage,numPerPage);
		close(conn);
		return list;
		
	}
	
	//회원검색처리하기
	public int selectCountMember(String type, String key) {
		Connection conn=getConnection();
		int result=dao.selectCountMember(conn,type,key);
		close(conn);
		return result;
		
	}
	
	public List<Member> selectMemberList(String type,String key, int cPage,int numPerPage){
		Connection conn=getConnection();
		List<Member> list=dao.selectMemberList(conn,type,key,cPage,numPerPage);
		close(conn);
		return list;
	}
	
	
	
	
}











