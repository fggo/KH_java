package com.kh.board.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.kh.board.model.service.BoardService;
import com.kh.board.model.vo.BoardComment;

@WebServlet("/board/boardCommentInsert")
public class BoardCommentInsert extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7637823695647782862L;

	public BoardCommentInsert() {
		super();
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int boardRef=Integer.parseInt(req.getParameter("board_ref"));
		String writer=req.getParameter("writer");
		int level=Integer.parseInt(req.getParameter("level"));
		String content=req.getParameter("content");
		int commentRef=Integer.parseInt(req.getParameter("commentRef"));
		
		BoardComment bc=new BoardComment(level,writer,content,boardRef,commentRef);
		int result=new BoardService().insertComment(bc);
		
		String msg="";
		String loc="/board/boardView?boardNo="+boardRef;
		String view="/views/common/msg.jsp";
		msg=result>0?"댓글등록 성공":"댓글등록 실패";
		req.setAttribute("msg",msg);
		req.setAttribute("loc",loc);
		req.getRequestDispatcher(view)
		.forward(req,resp);	
		
		
		
		
		
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(req,resp);
	}
	
	
	
	
}
