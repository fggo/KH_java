package com.kh.notice.model.service;

import static common.template.JDBCTemplate.getConnection;

import java.sql.Connection;
import java.util.List;
import static common.template.JDBCTemplate.close;
import com.kh.notice.model.dao.NoticeDao;
import com.kh.notice.model.vo.Notice;
import static common.template.JDBCTemplate.commit;
import static common.template.JDBCTemplate.rollback;

public class NoticeService {

	private NoticeDao dao=new NoticeDao();
	
	public int selectCountNotice() {
		Connection conn=getConnection();
		int result=dao.selectCountNotice(conn);
		close(conn);
		return result;
	}
	
	public List<Notice> selectNotice(int cPage,int numPerPage){
		Connection conn=getConnection();
		List<Notice> list=dao.selectNotice(conn,cPage,numPerPage);
		close(conn);
		return list;
	}
	
	public Notice selectNoticeOne(int no) {
		Connection conn=getConnection();
		Notice n=dao.selectNoticeOne(conn,no);
		close(conn);
		return n;
	}
	
	public int insertNotice(Notice n) {
		Connection conn=getConnection();
		int result=dao.insertNotice(conn,n);
		if(result>0) {commit(conn);}
		else {rollback(conn);}
		close(conn);
		return result;
	}
	
}













