package common.filter.wrapper;

import java.nio.charset.Charset;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;

public class EncyptWrapper extends HttpServletRequestWrapper {
	//작게한거는 제가아니라 무관씨!
	public EncyptWrapper(HttpServletRequest request) {
		super(request);
	}
	
	@Override
	public String getParameter(String name) {
		String value="";
		if(name!=null && name.equals("password")) {
			value=getSha512(super.getParameter(name));
			System.out.println("암호화된 비번 : "+value);
			return value;
		}
		else {
			return super.getParameter(name);
		}
	}
	
	private String getSha512(String val) {
		
		String encPwd="";
		MessageDigest md=null;
		System.out.println(val);
		try {
			md=MessageDigest.getInstance("SHA-512");
			
		}catch(NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
		byte[] bytes=val.getBytes(Charset.forName("UTF-8"));
		
		md.update(bytes);
		
		encPwd=Base64.getEncoder().encodeToString(md.digest());		
		return encPwd;
		
	}
	
	
}






