package com.kh.board.model.vo;

import java.sql.Date;

public class Board {

	private int boardNo;
	private String boardTitle;
	private String boardWriter;
	private String boardContent;
	private String boardOriFileName;
	private String boardReFileName;
	private Date boardDate;
	private int readCount;
	
	public Board() {
		// TODO Auto-generated constructor stub
	}
	
	public Board(String boardTitle,String boardWriter, 
			String boardContent, String oriFile, String refile) {
		this.boardTitle=boardTitle;
		this.boardWriter=boardWriter;
		this.boardContent=boardContent;
		this.boardOriFileName=oriFile;
		this.boardReFileName=refile;
	}
	
	public Board(int boardNo, String boardTitle, String boardWriter, String boardContent, String boardOriFileName,
			String boardReFileName, Date boardDate, int readCount) {
		super();
		this.boardNo = boardNo;
		this.boardTitle = boardTitle;
		this.boardWriter = boardWriter;
		this.boardContent = boardContent;
		this.boardOriFileName = boardOriFileName;
		this.boardReFileName = boardReFileName;
		this.boardDate = boardDate;
		this.readCount = readCount;
	}

	public int getBoardNo() {
		return boardNo;
	}

	public void setBoardNo(int boardNo) {
		this.boardNo = boardNo;
	}

	public String getBoardTitle() {
		return boardTitle;
	}

	public void setBoardTitle(String boardTitle) {
		this.boardTitle = boardTitle;
	}

	public String getBoardWriter() {
		return boardWriter;
	}

	public void setBoardWriter(String boardWriter) {
		this.boardWriter = boardWriter;
	}

	public String getBoardContent() {
		return boardContent;
	}

	public void setBoardContent(String boardContent) {
		this.boardContent = boardContent;
	}

	public String getBoardOriFileName() {
		return boardOriFileName;
	}

	public void setBoardOriFileName(String boardOriFileName) {
		this.boardOriFileName = boardOriFileName;
	}

	public String getBoardReFileName() {
		return boardReFileName;
	}

	public void setBoardReFileName(String boardReFileName) {
		this.boardReFileName = boardReFileName;
	}

	public Date getBoardDate() {
		return boardDate;
	}

	public void setBoardDate(Date boardDate) {
		this.boardDate = boardDate;
	}

	public int getReadCount() {
		return readCount;
	}

	public void setReadCount(int readCount) {
		this.readCount = readCount;
	}

	@Override
	public String toString() {
		return "Board [boardNo=" + boardNo + ", boardTitle=" + boardTitle + ", boardWriter=" + boardWriter
				+ ", boardContent=" + boardContent + ", boardOriFileName=" + boardOriFileName + ", boardReFileName="
				+ boardReFileName + ", boardDate=" + boardDate + ", readCount=" + readCount + "]";
	}
	
	
	
}






